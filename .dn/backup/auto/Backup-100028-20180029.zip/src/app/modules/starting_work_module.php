<?php
namespace app\modules;

use php\gui\framework\AbstractModule;


class starting_work_module extends AbstractModule
{

}