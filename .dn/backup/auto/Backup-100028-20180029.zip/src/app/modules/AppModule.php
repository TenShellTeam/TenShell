<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent; 
use php\gui\event\UXMouseEvent; 


class AppModule extends AbstractModule
{





}
