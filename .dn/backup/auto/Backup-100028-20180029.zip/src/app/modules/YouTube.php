<?php
namespace app\modules;

use php\gui\framework\AbstractModule;


class YouTube extends AbstractModule
{

}