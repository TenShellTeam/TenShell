<?php
namespace app\modules;

use php\gui\framework\AbstractModule;


class TenShell extends AbstractModule
{

}