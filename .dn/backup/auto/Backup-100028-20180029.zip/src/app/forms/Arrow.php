<?php
namespace app\forms;

use php\gui\framework\AbstractForm;


class Arrow extends AbstractForm
{

}