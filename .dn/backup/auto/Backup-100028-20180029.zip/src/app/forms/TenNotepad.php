<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXWindowEvent; 
use action\Element; 
use php\io\Stream; 


class TenNotepad extends AbstractForm
{

    /**
     * @event image3.click-Left 
     */
    function doImage3ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event Open.click-Left 
     */
    function doOpenClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event Save.click-Left 
     */
    function doSaveClickLeft(UXMouseEvent $event = null)
    {    
        
    }




}
