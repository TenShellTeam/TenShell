<?php
namespace app\forms;

use php\gui\framework\AbstractForm;


class Dev_Room extends AbstractForm
{

}