<?php
namespace app\forms;

use php\gui\framework\AbstractForm;


class Error_TenMusic1 extends AbstractForm
{

}