<?php
namespace app\forms;

use php\gui\framework\AbstractForm;


class TenMusic_Error extends AbstractForm
{

}