<?php
namespace app\forms;

use php\gui\framework\AbstractForm;


class Safe_Desktop extends AbstractForm
{

}