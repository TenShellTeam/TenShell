<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXEvent; 
use php\gui\event\UXKeyEvent; 


class TenBrowser extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $event = null)
    {    
        
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event labelAlt.click-Left 
     */
    function doLabelAltClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event home_page.click-Left 
     */
    function doHome_pageClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event vkicon.click-Left 
     */
    function doVkiconClickLeft(UXMouseEvent $event = null)
    {    
        
    }


    /**
     * @event buttonsearch.action 
     */
    function doButtonsearchAction(UXEvent $event = null)
    {    
        
    }

    /**
     * @event edit.keyDown-Enter 
     */
    function doEditKeyDownEnter(UXKeyEvent $event = null)
    {    
        
    }

    /**
     * @event label4.click-Left 
     */
    function doLabel4ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

}
