<?php
namespace app\modules;

use php\gui\framework\AbstractModule;


class Accounts extends AbstractModule
{

}