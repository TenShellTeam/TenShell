<?php
namespace app\modules;

use php\gui\framework\AbstractModule;


class TenModules extends AbstractModule
{

}