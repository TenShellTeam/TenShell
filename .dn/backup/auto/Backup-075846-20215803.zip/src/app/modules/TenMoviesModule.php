<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent; 
use action\Element; 
use php\io\Stream; 


class TenMoviesModule extends AbstractModule
{


}
